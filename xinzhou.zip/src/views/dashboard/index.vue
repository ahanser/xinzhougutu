<template>
  <div>
    <div id="viewDiv"></div>
  </div>
</template>

<script>
export default {
  methods: {}
}
</script>

<style>
#viewDiv {
  width: 100%;
  height: 500px;
}
</style>
