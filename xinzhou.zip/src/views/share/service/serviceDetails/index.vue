<template>
    <div>
        服务明细
    </div>
</template>

<script>
export default {
  name: 'Layout',
  components: {},
  computed: {},
  mounted() {},
  watch: {},
  methods: {}
}
</script>
<style rel="stylesheet/scss" lang="scss" scoped>
</style>
