<template>
    <div>
        建设用地分布
    </div>
</template>

<script>
export default {
  name: 'Layout',
  components: {},
  computed: {},
  mounted() {},
  watch: {},
  methods: {}
}
</script>
<style rel="stylesheet/scss" lang="scss" scoped>
</style>
