<template>
    <div>
        查询窗口
    </div>
</template>

<script>
export default {
  name: 'Layout',
  components: {},
  computed: {},
  mounted() {},
  watch: {},
  methods: {}
}
</script>
<style rel="stylesheet/scss" lang="scss" scoped>
</style>
