<template>
    <div>
     <timePerformace/>
     <br>   
     <jsMermory/>
    </div>
</template>
<script>
import timePerformace from './timePerformace'
import jsMermory from './jsMermory'
export default {
    components:{
        timePerformace:timePerformace,
        jsMermory:jsMermory
    }
}
</script>

